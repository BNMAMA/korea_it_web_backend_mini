package com.korit.BoardStudy.entity;

import lombok.Data;

@Data
public class Role {
    private Integer roleId;
    private String roleName;
    private String roleNameKor;
}